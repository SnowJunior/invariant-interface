# Invariant Lab implementation

Maintain the interactive static webpage described in PLAN.md. README.md documents the implementation and VERIFICATION.md records completed checks.

- Use buildless HTML, CSS, JavaScript ES modules, and original SVG characters.
- Clearly label simulated agents, type checks, and test outcomes. Markdown provides guidance; the validation gate enforces enabled rules.
- Keep candidate source, accepted source, isolated test state, and live stock separate.
- Preserve deterministic scenario results across speed, skin, reduced motion, and slapstick settings.
- All controls must work with keyboard input. Respect reduced motion. Never rely on color alone.
- Restart and mode changes must cancel prior timelines and animations.
- Display actual scenario evidence and the exact modeled Go snippet; do not invent metrics.
- Keep source changes within your assigned files when collaborating. Do not change .openai/hosting.json; the lead owns Site registration and publication.
- Verify behavioral engine tests and Go reference fixtures before completion.
